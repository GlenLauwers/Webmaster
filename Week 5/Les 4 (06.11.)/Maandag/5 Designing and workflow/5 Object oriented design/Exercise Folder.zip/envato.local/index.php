<!doctype html>
<html>
<head>
<title>Final Design</title>
<?php include'includes/head.php' ?>
</head>
<body>
<?php include'includes/header.php' ?>
<div id="blue_wrap">
<img src="images/sliderIMG.jpg" id="sliderIMG" alt="Main Slider" width="974" height="230">
</div>
<div id="wrapper">
<div id="content">
</div>
<?php include'includes/sidebar.php' ?>
</div></div>
<?php include'includes/footer.php'?>
</body>
</html>