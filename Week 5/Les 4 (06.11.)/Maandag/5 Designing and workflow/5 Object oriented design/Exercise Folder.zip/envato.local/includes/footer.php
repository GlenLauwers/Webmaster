<div id="footer"><div id="colwrap7">
<div id="foot_1">
<img src="images/map.jpg" id="Final_Design_r16_c5" alt="location of Envato"/>
<div id="colwrap10">
<div class="Txt_Envato">
<p class="lastNode">Envato Pty
</p>
</div>
<div class="Txt_Elizabeth">
<p>Elizabeth Street,</p><p>Melbourne VIC,</p><p>3000, Australia,</p><p>Contact Support</p><p class="lastNode">Tel: 8376 6284
</p>
</div>
<div class="clearFloat"></div>
</div>
</div>
</div>
<div id="colwrap9">
<div id="foot_2">
<form action="#" method="get">
<input type="text" name="Name" id="Name" value="Name">
<div class="clearFloat"></div>
<input type="text" name="Email" id="Email" value="Email">
<div class="clearFloat"></div>
<textarea name="message" id="message">Message</textarea>
<a href="#" id="send"></a>
</form>
<div class="clearFloat"></div>
</div>
</div>
<div id="foot_3">
<a href="#" class="footer_social twitter"></a>
<div class="Txt_Envato2">
<p class="lastNode">@Envato Twitter</p>
</div>
<div class="clearFloat"></div>
<a href="#" class="footer_social fb_f"></a>
<div class="Txt_Envato3">
<p class="lastNode">Envato Facebook</p>
</div>
<div class="clearFloat"></div>
<a href="#" class="footer_social li_f"></a>
<div class="Txt_Envato4">
<p class="lastNode">Envato Linked in</p>
</div>
</div>
<div class="copyright">
<p class="lastNode">TM Copyright all rights reserved
</p>
</div>
<img src="images/bottom_logo.png" id="Final_Design_r23_c8" alt="Envato Logo">
<div class="clearFloat"></div>
</div>