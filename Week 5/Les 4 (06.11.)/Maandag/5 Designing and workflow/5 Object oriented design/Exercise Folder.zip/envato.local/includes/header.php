<div id="main"><div id="h_wrap"><div id="header">
<img src="images/logo.jpg" id="logo" alt="Tuts Plus Logo"/>
<ul id="nav">
<li><a href="#"><p>Home</p></a></li>
<li><a href="#"><p>About</p></a></li>
<li><a href="#"><p>Services</p></a></li>
<li><a href="#"><p>Contact</p></a></li>
</ul>
<a href="http://www.linkedin.com/" class="social_buttons li_h"></a>
<a href="http://www.facebook.com/" class="social_buttons fb"></a>
<a href="http://www.twitter.com/" class="social_buttons twit"></a>
</div></div>