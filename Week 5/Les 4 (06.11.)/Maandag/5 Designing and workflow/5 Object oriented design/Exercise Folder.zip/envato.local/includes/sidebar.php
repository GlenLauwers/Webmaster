<div id="colwrap6">
<div id="sidebar_bg">
<a href="http://www.linkedin.com/" class="social_buttons li_h"></a>
<a href="http://www.facebook.com/" class="social_buttons fb"></a>
<a href="http://www.twitter.com/" class="social_buttons twit"></a>
<img src="images/sideIMG.jpg" id="sideIMG" alt="Envato logo">
<h3 class="h3_Twitter">Twitter</h3>
<div class="clearFloat"></div>
<div class="tweet">
<p class="lastNode">@bradclarkuk Sorry. Support has been backed up with tickets. What&rsquo;s your ticket number? I&rsquo;ll get them to look at it. Thanks! ^TK</p>
</div>
<a href="#" class="follow" id="follow_t"></a>
</div></div>