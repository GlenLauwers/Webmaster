<meta charset="utf-8"/>
<link rel="stylesheet" type="text/css" href="/main.css" media="all"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'/>
<!--[if IE]>
<style type="text/css" media="all">.borderitem{border-style:solid}</style>
<![endif]-->