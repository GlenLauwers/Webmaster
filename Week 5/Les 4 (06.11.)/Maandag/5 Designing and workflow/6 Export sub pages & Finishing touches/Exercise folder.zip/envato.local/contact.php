<!doctype html>
<html>
<head>
<title>Final Design</title>
<?php include'includes/head.php' ?>
</head>
<body id="page4">
<?php include'includes/header.php' ?>
<div id="sub_wrap">
<img src="images/sub_slider.jpg" id="sliderIMG" alt="Sub Slider" width="974" height="230">
</div>
<div id="wrapper">
<div id="content">
<img src="images/map_contact.jpg" id="map_contact" alt="Envato location" />
<div class="clearFloat"></div>
<img src="images/contact_r3_c2.gif" id="contact_r3_c2" alt="" />
<div id="main_contact">
<h3 class="h3_CF_title">Contact Form</h3>
<div class="clearFloat"></div>
<form action="#" method="get">
<input type="text" name="CF_NAME" id="CF_NAME" value="Name" />
<div class="clearFloat"></div>
<input type="text" name="CF_EMAIL" id="CF_EMAIL" value="Email" />
<div class="clearFloat"></div>
<a href="#" id="main_CF_SEND">SEND</a>
<textarea name="CF_MESSAGE" id="CF_MESSAGE">Message</textarea>
</form>
</div>
<div id="colwrap1">
<h2 class="h2_Envato_location">
Envato Pty
</h2>
<div class="envato_address">
<p>Elizabeth Street,</p><p>Melbourne VIC,</p><p>3000, Australia,</p><p>Contact Support</p><p class="lastNode">Tel: 8376 6284
</p>
</div>
</div>
</div>
<?php include'includes/sidebar.php' ?>
</div></div>
<?php include'includes/footer.php'?>
</body>
</html>