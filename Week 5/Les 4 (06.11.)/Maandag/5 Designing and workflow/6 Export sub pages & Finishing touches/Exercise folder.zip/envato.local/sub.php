<!doctype html>
<html>
<head>
<title>Final Design</title>
<?php include'includes/head.php' ?>
</head>
<body>
<?php include'includes/header.php' ?>
<div id="sub_wrap">
<img src="images/sub_slider.jpg" id="sliderIMG" alt="Sub Slider" width="974" height="230">
</div>
<div id="wrapper">
<div id="content">
</div>
<?php include'includes/sidebar.php' ?>
</div></div>
<?php include'includes/footer.php'?>
</body>
</html>