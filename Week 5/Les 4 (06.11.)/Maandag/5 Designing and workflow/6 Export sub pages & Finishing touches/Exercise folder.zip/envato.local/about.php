<!doctype html>
<html>
<head>
<title>About Page</title>
<?php include'includes/head.php' ?>
</head>
<body id="page2">
<?php include'includes/header.php' ?>
<div id="sub_wrap">
<img src="images/sub_slider.jpg" id="sliderIMG" alt="Sub Slider" width="974" height="230">
</div>
<div id="wrapper">
<div id="content">
<img src="images/about_pic.png" id="about_pic" alt="about us" width="233" height="180"/>
<div id="about1">
<h2 class="h2_about_title">Web Designer</h2>
<div class="clearFloat"></div>
<div class="about_txt1">
<p class="lastNode">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum commodo lacus, ut condimentum justo fermentum id. Ut leo augue, lobortis non iaculis id, tempus et quam. In vitae lobortis eros.
</p>
</div>
</div>
<div id="about2">
<h2 class="h2_about_title2">Marketer</h2>
<div class="clearFloat"></div>
<div class="about_txt2">
<p class="lastNode">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum commodo lacus, ut condimentum justo fermentum id. Ut leo augue, lobortis non iaculis id, tempus et quam. In vitae lobortis eros.
</p>
</div>
</div>
<img src="images/about_pic.png" id="about_pic2" alt="about us" width="233" height="180" />
<div class="about_txt3">
<p class="lastNode">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum commodo lacus, ut condimentum justo fermentum id. Ut leo augue, lobortis non iaculis id, tempus et quam. In vitae lobortis eros. Aenean fermentum, tellus non varius fermentum, arcu lorem.
</p>
</div>
</div>
<?php include'includes/sidebar.php' ?>
</div></div>
<?php include'includes/footer.php'?>
</body>
</html>