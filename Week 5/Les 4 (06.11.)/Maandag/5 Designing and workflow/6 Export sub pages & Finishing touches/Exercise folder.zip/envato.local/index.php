<!doctype html>
<html>
<head>
<title>Final Design</title>
<?php include'includes/head.php' ?>
</head>
<body id="page1">
<?php include'includes/header.php' ?>
<div id="blue_wrap">
<img src="images/sliderIMG.jpg" id="sliderIMG" alt="Main Slider" width="974" height="230">
</div>
<div id="wrapper">
<div id="content">
<h1 class="h1_title">Fireworks for Web Designers</h1>
<div class="home_txt1">
<p class="lastNode">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean convallis sagittis eros, nec tristique mauris fringilla in. Mauris id ante id erat tempus scelerisque. Nunc dignissim auctor pulvinar. In est orci, pharetra sed ornare ac, laoreet ac diam. Phasellus faucibus varius erat a convallis. Donec luctus vulputate augue sit amet varius. Duis lacinia turpis quis enim posuere egestas. Praesent mattis mollis felis, nec viverra sapien placerat sed. Nulla suscipit, ligula non luctus posuere, ligula justo luctus arcu, id molestie velit turpis ac dui. Morbi rutrum suscipit est, ut posuere lacus convallis vitae. Nullam mattis tristique malesuada. Suspendisse dictum feugiat lectus, a iaculis diam consectetur a. Nam sed ligula arcu. Donec convallis dolor sed magna suscipit tincidunt. Sed ac diam quis nulla adipiscing faucibus.
</p>
</div>
<div class="home_txt2">
<p class="lastNode">Praesent pretium quam quis neque tristique id placerat nisi sollicitudin. Pellentesque hendrerit diam non dui pretium a ornare mauris lacinia. Integer nec velit sem, vel ultrices nibh. Duis vestibulum nibh vitae justo posuere ut venenatis nulla aliquet. Nulla a leo ut metus consequat congue id in neque. Nulla est mauris, lobortis eu lobortis ut, pretium vitae elit.
</p>
</div>
</div>
<?php include'includes/sidebar.php' ?>
</div></div>
<?php include'includes/footer.php'?>
</body>
</html>