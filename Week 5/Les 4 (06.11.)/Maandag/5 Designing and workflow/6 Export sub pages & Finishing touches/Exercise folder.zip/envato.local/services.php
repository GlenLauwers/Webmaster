<!doctype html>
<html>
<head>
<title>Final Design</title>
<?php include'includes/head.php' ?>
</head>
<body id="page3">
<?php include'includes/header.php' ?>
<div id="sub_wrap">
<img src="images/sub_slider.jpg" id="sliderIMG" alt="Sub Slider" width="974" height="230">
</div>
<div id="wrapper">
<div id="content">
<div id="services_col1">
<img src="images/business.gif" id="business" alt="" />
<div class="clearFloat"></div>
<h2 class="h2_business">
Business
</h2>
<div class="clearFloat"></div>
<div class="servicestxt1">
<p class="lastNode">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum commodo lacus, ut condimentum justo fermentum id.
</p>
</div>
<div class="clearFloat"></div>
<a href="#" class="services_more"></a>
<div class="clearFloat"></div>
</div>
<div id="services_col3">
<img src="images/social.gif" id="social" alt="" />
<div class="clearFloat"></div>
<h2 class="h2_Social">
Social
</h2>
<div class="clearFloat"></div>
<div class="servicestxt3">
<p class="lastNode">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum commodo lacus, ut condimentum justo fermentum id.
</p>
</div>
<a href="#" class="services_more"></a>
</div>
<div id="services_col2">
<img src="images/web.gif" id="web" alt="" />
<div class="clearFloat"></div>
<h2 class="h2_Web">
Web 2.0
</h2>
<div class="clearFloat"></div>
<div class="servicestxt2">
<p class="lastNode">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum commodo lacus, ut condimentum justo fermentum id.</p>
</div>
<a href="#" class="services_more"></a>
</div>
</div>
<?php include'includes/sidebar.php' ?>
</div></div>
<?php include'includes/footer.php'?>
</body>
</html>