<div id="main"><div id="h_wrap"><div id="header">
<img src="images/logo.jpg" id="logo" alt="Tuts Plus Logo"/>
<ul id="nav">
<li><a href="index.php" id="navbtn1"><p>Home</p></a></li>
<li><a href="about.php" id="navbtn2"><p>About</p></a></li>
<li><a href="services.php" id="navbtn3"><p>Services</p></a></li>
<li><a href="contact.php" id="navbtn4"><p>Contact</p></a></li>
</ul>
<a href="http://www.linkedin.com/" class="social_buttons li_h"></a>
<a href="http://www.facebook.com/" class="social_buttons fb"></a>
<a href="http://www.twitter.com/" class="social_buttons twit"></a>
</div></div>